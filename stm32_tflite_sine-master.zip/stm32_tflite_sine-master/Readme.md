# TensorFlow Lite model on STM32

[![License](https://img.shields.io/badge/license-MIT-red)](https://opensource.org/licenses/MIT)
[![Blog](https://img.shields.io/badge/blog-post-yellow)](https://mirzafahad.github.io/2020-06-16-tflite-stm32/)

:star: Star me on GitHub — it helps!

An attempt to run TFLite model on STM32. More details can be found [here](https://mirzafahad.github.io/2020-06-16-tflite-stm32/).

![output on LCD](/output.gif)